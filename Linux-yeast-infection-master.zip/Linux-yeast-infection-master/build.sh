cd source
make
make clean
mv handler ../handler
