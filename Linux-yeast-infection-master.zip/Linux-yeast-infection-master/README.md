<p align="center">
<img src="https://github.com/EchoNine/L1nux-7east-1nfecti0n/blob/master/sk-bl.gif">
</p>




DESCRIPTION:


this is a fork bomb
it runs as .handler
it gets automatically added to rc.d
it crashes computer after 20 mins
it is recognised as a service (.handler)


BASIC SETUP:


bash build.sh
bash script





DISCLAIMER:

* These scripts are for educational & pentesting purposes only. 
* Use it at your own risk as i am not liable, nor will i be held responsible of its use or abuse in any case.

