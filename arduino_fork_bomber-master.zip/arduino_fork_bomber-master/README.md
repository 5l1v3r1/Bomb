# arduino_fork_bomber

A fork bomb (also called rabbit virus or wabbit) is a denial-of-service attack wherein a process continually replicates itself to deplete available system resources, slowing down or crashing the system due to resource starvation. Fork bombs operate both by consuming CPU time in the process of forking, and by saturating the operating system's process table. A basic implementation of a fork bomb is an infinite loop that repeatedly launches the same process.

# How to use - 

Just load the program to your arduino based on Atmega32U4 and plug it into any Windows/Linux system you want to crash.

**Make sure to unplug the arduino from the USB as soon as you upload the exploit else the code would be executed in your system.**

**Note**- The program is only made for educational purposes. The creator or the contributor of the code in anyway doesn't hold the responsibilty for the damages caused to the computer(s) and/or its data/information on which this program/code is executed. 
