# HTML-Fork-Bomb.github.io

I created a simple Fork Bomb page using just a few html, css and javascript.

Opening the page the browser will try to open many popups </BR>
(in new browsers you must first give permission, otherwise they are locked by default),</BR>
until all the computer's ram is used, resulting in a browser, and also a computer, crash!

For this project I was inspired by this fantastic fork-bomb list:

https://github.com/aaronryank/fork-bomb

</BR>

<h3>Fork Bomb Explanation</h3>

https://it.wikipedia.org/wiki/Fork_bomb

![Alt text](https://raw.githubusercontent.com/JonnyBanana/HTML-Fork-Bomb.github.io/master/img/1300px-Fork_bomb.png)

</BR>

<h3> Browser Compatibility </h3>

All

</BR>

Try at your Risk Here: https://jonnybanana.github.io/HTML-Fork-Bomb.github.io/

</BR>

![Alt text](https://github.com/JonnyBanana/HTML-Fork-Bomb.github.io/blob/master/img/firefox-boom.JPG)




</BR>

<!-- Banner -->
<div align="center">
<a href="https://www.purevpn.com/order-now.php?aff=44922&amp;a_bid=bbd0f893" target="_blank" ><img src="https://affiliates.purevpn.com/accounts/default1/6hb82wqa2l/bbd0f893.jpg" alt="Best VPN" title="Best VPN" width="728" height="90" /></a>
</BR></BR>
</div>


