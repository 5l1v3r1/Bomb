import createpng_lib as createpng

from sys import argv

# converting chunk types
typearr = {'IHDR': ['\x49', '\x48', '\x44', '\x52'],
			'IEND':['\x49', '\x45', '\x4e', '\x44'],
			'IDAT':['\x49', '\x44', '\x41', '\x54'],
			'tEXt':['\x74', '\x45', '\x58', '\x74'],
			'zTXt':['\x7a', '\x54', '\x58', '\x74'],
			'pHYs':['\x70', '\x48', '\x59', '\x73'],
			'sPLT':['\x73', '\x50', '\x4c', '\x54'],
			}


###
# create new png with png identifier
f = createpng.create_png(argv[1])

#--------------------------------------------------------------------------
###
# IHDR		(Basic header)
'''
			http://www.libpng.org/pub/png/spec/1.1/PNG-Chunks.html#C.IHDR
   Width:              4 bytes
   Height:             4 bytes
   Bit depth:          1 byte
   Color type:         1 byte
   Compression method: 1 byte
   Filter method:      1 byte
   Interlace method:   1 byte
   '''
createpng.write_chunk(typearr['IHDR'], 
			['\x00', '\x00', '\x00', '\x01',	# width
			'\x00', '\x00', '\x00', '\x01', 	# height
			'\x08',								# bit depth
			'\x00',								# color type
			'\x00',								# compression method
			'\x00',								# filter method
			'\x00']								# interlace method
			, f)



#--------------------------------------------------------------------------
###
# pHYs		(The pHYs chunk specifies the intended pixel size or aspect ratio for display of the image. It contains:
#
#   Pixels per unit, X axis: 4 bytes (unsigned integer)
#   Pixels per unit, Y axis: 4 bytes (unsigned integer)
#   Unit specifier:          1 byte



#--------------------------------------------------------------------------
###
# sPLT

# 
#   Palette name:    1-79 bytes (character string)
#   Null terminator: 1 byte
#   Sample depth:    1 byte
#   Red:             1 or 2 bytes
#   Green:           1 or 2 bytes
#   Blue:            1 or 2 bytes
#   Alpha:           1 or 2 bytes
#   Frequency:       2 bytes

#--------------------------------------------------------------------------
###
# A zTXt chunk contains:

#   Keyword:            1-79 bytes (character string)
#   Null separator:     1 byte
#   Compression method: 1 bytes			has to be zero
#   Compressed text:    n bytes			is zlib compression

keyword = ['\x41', '\x00']

import zlib

dat = 'a' * 0xfffffff
compdat = zlib.compress(dat,9)
compdata = []
compdata += [i for i in compdat]

for i in range(3):
	createpng.write_chunk(typearr['zTXt'], 
				keyword +
				['\x00'] +
				compdata
				,f)




#--------------------------------------------------------------------------
###
# IDAT		(actual image data)
createpng.write_chunk(typearr['IDAT'], 
			['\x08',
			'\xd7','\x63','\x78',
			'\x05','\x00','\x00',
			'\xec','\x00','\xeb']
			, f)


#--------------------------------------------------------------------------
###
# tEXt test

# kan van alles in staan

# kan foutmeldingen genereren
# convert: invalid keyword character 0x14 `eh.png' @ warning/png.c/MagickPNGWarningHandler/1830.
# convert: trailing spaces removed from keyword `eh.png' @ warning/png.c/MagickPNGWarningHandler/1830.
# convert: Zero length keyword `eh.png' @ warning/png.c/MagickPNGWarningHandler/1830.



#--------------------------------------------------------------------------
###
# IEND		(End of PNG)
createpng.write_chunk(typearr['IEND'], [], f)


f.close()















