# ZipBomber
Basic Implementation Of Zip Bomber With Python.The Zipbomb.py script asks you the amount of gbs of which you want to generate Zipbomb.zip file.The Extract_All.py script will extract all zip files inside Zipbomb.zip file recursively and will finally crash the system if there is not enough hard-disk space.
Warning-Please Test this script with small amount of gbs.

# Requirements
Python 2.7
Linux Platform
Make Sure zip command is working on terminal
