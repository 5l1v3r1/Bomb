# Branch Bomb

#### *:(){ :|: & };: for Git Branches*
***

Python Version

