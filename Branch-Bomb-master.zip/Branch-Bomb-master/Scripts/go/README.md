# Branch Bomb

#### *:(){ :|: & };: for Git Branches*
***

Go Version.

