# Branch Bomb

#### *:(){ :|: & };: for Git Branches*
***

Continuously create and spawn local and remote Git branches for a repo.

**Currently a Work-In-Progress -- Documentation will be updated on Completion for each language**