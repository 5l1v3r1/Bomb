# Changelog

All Notable changes to `laravel-zipbomb` will be documented in this file

## 1.0.0 - 2017-07-08

- Initial release
