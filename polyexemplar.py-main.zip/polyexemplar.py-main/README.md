# polyexemplar.py
## General Information
| Field | Value |
| :---- | :---- |
| Project | polyexemplar.py |
| License | UNLICENSE license |
| Author | Larry "Diicorp95" Holst |
| Purpose | An exploit |

## The Virus Properties
| Field | Value |
| :---- | :---- |
| Polymorphic | No |
| Breeds or infects | No |
| Performs disk I/O | No |
| Exploit | Yes |
| Behaviour | *Program tries to cause stack overflow, fill up all free available RAM, overload PUs.* |

## Legal Information
* USE THE CODE FOR EDUCATIONAL PURPOSE AND SYSTEM RESILIENCE TESTS ONLY.
* DO NOT RUN IT ON AN ELECTRONIC COMPUTING DEVICE OTHER THAN YOUR OWN. IT'S CRIMINALLY PUNISHABLE, BECAUSE YOU DAMAGE SOMEONE ELSE'S PROPERTY.
* NO GUARANTEE THAT YOUR DEVICE WILL NOT BE DAMAGED. EVERYTHING IS AT YOUR OWN RISK.

The original idea by Larry "Diicorp95" Holst. Do not distribute it illegally. Do not spread it. Any change in the program code will result in it no longer being this project. Licensed under [UNLICENSE license](https://unlicense.org).
